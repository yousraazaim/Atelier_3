#include<iostream>
using namespace std;

class Myclass{
	public :
		Myclass();
		~Myclass();
};
Myclass::Myclass(){
	cout<<"constructeur"<<endl;
}
Myclass::~Myclass(){
	cout<<"destructeur"<<endl;
}

int main(){
	Myclass M;
} 









