#include<iostream>
#include<math.h>
using namespace std;
class test{
	public:
		static int cmp;
		int call()
		{
			cmp++;
			cout<<cmp<<"\n" ;
			
		}
};
int test::cmp=0;
int main()
{
	test t1,t2;
	t1.call();
	t2.call();
}

