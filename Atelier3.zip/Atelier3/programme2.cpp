#include<iostream>
using namespace std;

class Shape{
	protected:
		float largeur,hauteur;
	public:
		Shape(float largeur,float hauteur){
			this->largeur=largeur;
			this->hauteur=hauteur;
		}
		virtual float area()=0;
		
};

class Triangle:public Shape{
	public :
		Triangle(float x,float y):Shape(x,y){}
		float area(){
			return (largeur*hauteur)/2;
		}
	
};
class Rectangle:public Shape{
	public :
	    Rectangle(float x,float y):Shape(x,y){}
	    float area(){
			return (largeur*hauteur);
	}
	
};
	
int main(){

	Triangle t(6,2);
    Rectangle r(4,8);
	
	cout<<"surface du triangle est : "<<t.area()<<endl;
	cout<<"surface du rectangle est : "<<r.area()<<endl;	
} 



