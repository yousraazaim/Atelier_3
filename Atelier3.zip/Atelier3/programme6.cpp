#include<iostream>
using namespace std;

class Personne {
	private :
		      string nom;
		      string prenom;
		      string date_naissance;
	public:
		  Personne(string nom,string prenom,string date_naissance)
		   {
		   	this->nom=nom;
		   	this->prenom=prenom;
		   	this->date_naissance=date_naissance;
		   }
	    virtual void afficher() {
	          	cout <<"Nom="<<nom<<" Prenom="<<prenom<<" date de naissance="<<date_naissance;
			  }
};
class Employe:public Personne {
	
	protected :
		        float salaire;
	public :
		     Employe(string nom,string prenom,string date_naissance,float salaire) : Personne(nom,prenom,date_naissance) {
		     	this->salaire=salaire;
			 }
		void afficher()	{
			Personne::afficher();
			cout <<" Salaire= "<<salaire <<" ";
		}
};



class Chef:public Employe{
	protected :
		        string service;
	public :
		    Chef(string nom,string prenom,string date_naissance,float salaire,string service) : Employe(nom,prenom,date_naissance,salaire)
		    {
		    	this->service=service;
			}
};

int main()
{
	int i;
	Personne *T[5];
	T[0]=new  Personne("N1","Personne1","02/09/2019");
	T[1]=new Employe("N2","Personne2","15/05/2020",2500);
	
	for(i=0;i<2;i++)
	 {
	    T[i]->afficher();
		cout<<endl;	
	 }
}




