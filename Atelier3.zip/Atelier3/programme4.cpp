#include<iostream>
using namespace std;
class mere{
	public:
		mere(){}
			void display()
			{
				cout<<"je suis la mere"<<endl;
			}
	
};
class fille:public mere{
	public:
	void display()
	{
		cout<<"je suis la fille"<<endl;
	}
};

	
int main()
{
	mere M;
	fille F;
	M.display();
	F.display();
}




