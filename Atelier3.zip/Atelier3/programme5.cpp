#include<iostream>
using namespace std;

class Animal{
	protected :
	   	string nom;
		int age;
	public :
		Animal(string nom,int age){
			this->nom=nom;
			this->age=age;
		}
		void set_value(int age){
			this->age=age;
		}
		void afficher(){
			cout<<"nom: "<<nom<<" age: "<<age;
		}
};

class Zebra:public Animal{
	private :
		string origine;	
	public :
		Zebra(string nom,int age,string origine):Animal(nom,age){  
			this->origine=origine;
		}
		void afficher(){
        Animal::afficher();
        cout<<" mon origine: "<<origine<<endl;}
        
};
class Dolphine:public Animal{
	private :
		string origine;
		
	public :
		Dolphine(string nom,int age,string origine):Animal(nom,age){
			this->origine=origine;
		}
		void afficher(){
			Animal::afficher();
			cout<<" mon origine: "<<origine<<endl;
		}
};

int main(){
	Zebra z (" zebra",16," Afrique");
	z.afficher();
	z.set_value(14);
	Dolphine d(" dolphine",10,"  Europe");
	d.afficher();
	d.set_value(19);
} 
















