#include<iostream>
#include<math.h>
using namespace std;
		class complexe{
			private:
				float reel,img;
			public:
				complexe(float reel=0,float img=0){
					this->reel=reel;
					this->img=img;
				}
			void afficher()
			{
				cout<<reel<<"i+"<<img<<endl;
			}
			complexe somme(complexe A)
			{
				complexe S;
				S.reel=reel+A.reel;
				S.img=img+A.img;
				return S;
			}
			float norme()
			{
				return sqrt(reel*reel+img*img);
			}
				
		};
		
		int main()
		{
			float B;
			complexe  y(5,4) , x(1,3) , z ;
			y.afficher();
			x.afficher();
			z=x.somme(y);
			z.afficher();
			B=y.norme();
			cout<<"la norme de y:"<<B<<endl;
		}
		
		
		
		
		
